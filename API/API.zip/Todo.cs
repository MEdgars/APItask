﻿namespace API
{
    public class Todo
    {
        public string id;
        public string firstName;
        public string lastName;
        public string hireDate;
        public string dischargeDate;
        public string position;
        public string managerId;
    }
}